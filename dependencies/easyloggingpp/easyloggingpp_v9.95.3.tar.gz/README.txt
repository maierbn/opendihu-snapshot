﷽

# The Message
All the products by Muflihun Labs are primarily focused on *dawah*. We have a message to give to everyone out there.

The message is simple and easy to understand:

Allah ﷻ is The Creator, The Sustainer, The Controller of everything. Therefore, He ﷻ is the only one to be worshipped. All the prophets, including Prophet Abraham, Prophet Joseph, Prophet Jacob, Prophet Noah, Prophet Lot, Prophet Moses, Prophet Jesus and Prophet Muhammad ﷺ, and all other, (may Allah's peace and blessings be upon all of them) came with single message:

 > Worship Allah and avoid Taghut [Qur'aan, Surah An-Nahl 16:36]

We are your fellow human beings who worship no one but Him ﷻ and the only way to salvation is to accept the **Only** religion accepted by Allah ﷻ. Lest you be resurrected on the Day of Judgement and be thrown in to the Hellfire. Because, Allah ﷻ can forgive any sin but He ﷻ has clearly said that He ﷻ will **not** forgive the graviest sin, the sin of *shirk*. i.e, associating anyone with Allah ﷻ in His Lordship or His Names and Attributes or His worship.

 > Indeed, Allah does not forgive association with Him, but He forgives what is less than that for whom He wills. And he who associates others with Allah has certainly gone far astray. [Qur'aan, Surah An-Nisaa 4:116]

Do not listen to that which media feeds you, and do not believe in what media has fed you. Do your own research, if you are a seeker of truth and work towards it **with true sincerity**, then Allah ﷻ will guide you and show you the right path. You will then realise that Islaam is the only religion that is most sensible, and it can not be from anyone but the True God, Allah ﷻ.

Islaam is the **ONLY** religion accepted by Allah ﷻ. 

> And whoever desires other than Islam as religion - never will it be accepted from him, and he, in the Hereafter, will be among the losers. [Qur'aan, Surah Aali Imraan, 3:85]

 > Indeed, the religion in the sight of Allah is Islam. And those who were given the Scripture did not differ except after knowledge had come to them - out of jealous animosity between themselves. And whoever disbelieves in the verses of Allah, then indeed, Allah is swift in [taking] account. [Qur'aan, Surah Aali Imraan, 3:19]

To learn more, see https://muflihun.com/articles/islam

May Allah ﷻ guide you and keep us on the straight path 
