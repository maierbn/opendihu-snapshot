from __future__ import division, absolute_import, print_function

__version__ = '0.7.0'

from .numpydoc import setup
